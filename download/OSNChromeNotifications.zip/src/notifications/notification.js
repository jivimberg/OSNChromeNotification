document.getElementById("userImage").src = sessionStorage.imgSrc;
document.getElementById("titleText").innerHTML = sessionStorage.titleText;
document.getElementById("messageText").innerHTML = sessionStorage.messageText;